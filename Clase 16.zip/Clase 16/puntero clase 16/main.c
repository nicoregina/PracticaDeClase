#include <stdio.h>
#include <stdlib.h>

void mostrarCadena(char *); //header funcion.h

typedef struct{
    char nombre[51];
    int nota;
}alumno;

int main()//main
{
    alumno auxAlumno;
    alumno *punteroAlumno;
    punteroAlumno = &auxAlumno;
    strcpy(punteroAlumno-> nombre, "Hermes");
    punteroAlumno-> nota = 10;

    /*char cad[51];
    printf("ingrese una palabra: \n");
    scanf("%s",cad);
    mostrarCadena(cad);*/
    return 0;
}

void mostrarCadena(char *punteroCadena)//funcion.c
{
    while(*punteroCadena != '\0')
    {
        printf("%c", *punteroCadena);
        punteroCadena++;
    }
}
