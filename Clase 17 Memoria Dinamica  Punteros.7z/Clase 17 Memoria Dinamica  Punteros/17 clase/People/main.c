#include <stdio.h>
#include <stdlib.h>
#include "Person.h"

int main()
{
    Person* personArray[3];
    int i,edad;

    printf("ingrese edad de la persona %d: ", i);
    scanf("%d", &edad);
    for(i = 0; i < 3; i++)
    {
        personArray[i] = person_new(edad,i);
    }
    for(i = 0; i < 3; i++)
    {
        person_setAge(personArray[i],i/*-4*/);
    }
    for(i = 0; i < 3; i++)
    {
        printf("\nAge: %2d",person_getAge(personArray[i]));
    }
    scanf(" ");
    return 0;
}

